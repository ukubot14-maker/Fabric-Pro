# MyFabricMod‑orbitals

A simple Fabric mod that adds a renamed fishing rod called **Orbitals (Ukubot)**. Right‑clicking with the rod creates a huge explosion (a "nuke").

- **Single‑player**: The rod works out‑of‑the‑box.
- **Multiplayer**: By default it is disabled. An operator can enable it for all players with the command:
  ```
  /alloworbitals true
  ```
  and disable it again with `/alloworbitals false`.

## Installation
1. Install Fabric Loader **0.15.x** for Minecraft **1.21**.
2. Install the matching **Fabric API** version (0.102.0+1.21 or newer).
3. Drop the compiled JAR into your `mods` folder.

## Building from source
```bash
# Clone the repository (or copy the generated files)
git clone <repo‑url>
cd MyFabricMod-orbitals

# Use the Gradle wrapper if you have it, otherwise ensure Gradle 8+ is installed
./gradlew build   # on Windows use gradlew.bat
```
The compiled mod will be in `build/libs/`.

## Notes & Caveats
- The "nuke" is implemented as a radius‑20 explosion that destroys blocks (`Explosion.DestructionType.BREAK`). Use with caution.
- No persistent configuration is saved; the enable flag resets when the server restarts.
- The mod only registers one custom item (`orbital_rod`). It can be obtained via the `/give` command:
  ```
  /give @p myfabricmod_orbitals:orbital_rod
  ```
- The item name is hard‑coded to "Orbitals (Ukubot)"; it cannot be renamed further in an anvil.

## License
MIT – feel free to modify and redistribute.
