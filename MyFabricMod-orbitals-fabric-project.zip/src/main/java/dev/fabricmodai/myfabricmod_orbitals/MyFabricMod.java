package dev.fabricmodai.myfabricmod_orbitals;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

public class MyFabricMod implements ModInitializer {
    public static final String MOD_ID = "myfabricmod_orbitals";
    public static final Item ORBITAL_ROD = new OrbitalFishingRod(new FabricItemSettings().maxCount(1));
    private static boolean enabled = false; // default disabled for multiplayer

    @Override
    public void onInitialize() {
        // Register the custom item
        net.fabricmc.fabric.api.registry.FabricItemRegistry.INSTANCE.register(ORBITAL_ROD, "orbital_rod");

        // Register command
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("alloworbitals")
                .requires(source -> source.hasPermissionLevel(2)) // op only
                .then(CommandManager.argument("value", net.minecraft.command.argument.BoolArgumentType.bool())
                    .executes(this::setAllowOrbitals)));
        });

        // Right‑click handler
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (stack.getItem() == ORBITAL_ROD && hand == Hand.MAIN_HAND) {
                if (!world.isClient) {
                    if (world.isClient && !world.isClient) return ActionResult.PASS; // safety
                    if (world.isClient) return ActionResult.PASS;
                    // Single‑player worlds always allow, otherwise check flag
                    if (!world.isClient && !world.getServer().isSingleplayer() && !enabled) {
                        player.sendMessage(Text.literal("Orbitals are disabled on this server. Use /alloworbitals true as an op to enable."), false);
                        return ActionResult.FAIL;
                    }
                    // Create a massive explosion (nuke)
                    world.createExplosion(null, player.getX(), player.getY(), player.getZ(), 20.0f, Explosion.DestructionType.BREAK);
                    player.sendMessage(Text.literal("💥 Nuke detonated!"), false);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    private int setAllowOrbitals(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        boolean value = net.minecraft.command.argument.BoolArgumentType.getBool(ctx, "value");
        enabled = value;
        ctx.getSource().sendMessage(Text.literal("Orbitals " + (value ? "enabled" : "disabled") + " for all players."));
        return 1;
    }

    /**
     * Custom fishing rod that displays a renamed name in the tooltip.
     */
    private static class OrbitalFishingRod extends FishingRodItem {
        public OrbitalFishingRod(Settings settings) {
            super(settings);
        }

        @Override
        public Text getName(ItemStack stack) {
            return Text.literal("Orbitals (Ukubot)");
        }
    }
}
